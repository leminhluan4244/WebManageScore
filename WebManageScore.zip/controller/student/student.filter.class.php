<!--Start combobox class for student-->
<div class="col-sm-4 form-group">
    <select id="select-student-class" class="form-control" name="c">
        <option value="">-- Chọn theo lớp --</option>
    </select>
</div>
<!--End combobox class for student-->