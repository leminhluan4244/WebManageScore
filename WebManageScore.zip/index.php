<?php
/**
 * Created by PhpStorm.
 * User: TanPhat
 * Date: 11/9/2017
 * Time: 1:42 PM
 */
header("Location: controller/account/account.login.php");
?>
