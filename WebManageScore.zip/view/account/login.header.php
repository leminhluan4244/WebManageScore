<?php
/**
 * Created by PhpStorm.
 * User: tanphat
 * Date: 9/11/17
 * Time: 2:40 PM
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
		<title>Đăng nhập hệ thống</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="../../public/bootstrap/jquery-3.2.1.min.js"></script>
	<script src="../../public/bootstrap/js/bootstrap.min.js"></script>
<!--	<link rel="stylesheet" href="--><?php //echo $baseUrl; ?><!--/public/bootstrap/css/bootstrap.min.css">-->
<!--	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
<!--	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">-->
    <link rel="stylesheet" href="../../public/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../public/style/style.css">
	<link rel="icon" href="../../public/img/logo.gif">
</head>
<body>
<div class="banner container-fluid">
	<div class="col-sm-2 logo">
		<img src="../../public/img/logo.gif" width="90" alt="">
	</div>
	<div class="banner-title col-sm-10">
		<h4><strong>TRƯỜNG ĐẠI HỌC CẦN THƠ</strong></h4>
		<p><strong>Hệ thống chấm điểm rèn luyện</strong></p>
	</div>
</div>
<br>
