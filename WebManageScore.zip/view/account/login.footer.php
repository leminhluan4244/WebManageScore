<?php
/**
 * Created by PhpStorm.
 * User: tanphat
 * Date: 9/11/17
 * Time: 2:45 PM
 */
?>
<script src="../../public/js/common.js"></script>
<script src="../../public/js/account.js"></script>
<script>
    $(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
</body>
</html>